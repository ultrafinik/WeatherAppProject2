package ru.myitschool.lab23.model;

import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;

public class Money
{
    private Operation operation;
    private Date date;
    private double summa;
    public Money(Operation operation, Date date, double summa) {
        this.operation = operation;
        this.date = date;
        this.summa = summa;
    }
    public Operation getOperation() {
        return operation;
    }
    public void setOperation(Operation operation) {
        this.operation = operation;
    }
    public Date getDate() {
        return date;
    }
    public void setDate(Date date) {
        this.date = date;
    }
    public double getSumma() {
        return summa;
    }
    public void setSumma(double summa) {
        this.summa = summa;
    }
}
