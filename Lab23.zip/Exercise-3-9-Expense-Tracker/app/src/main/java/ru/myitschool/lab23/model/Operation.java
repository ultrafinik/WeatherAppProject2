package ru.myitschool.lab23.model;

public enum Operation
{
    Income,
    Expenses
}
