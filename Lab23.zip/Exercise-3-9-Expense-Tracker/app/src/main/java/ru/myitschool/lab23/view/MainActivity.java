package ru.myitschool.lab23.view;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import ru.myitschool.lab23.R;
import ru.myitschool.lab23.databinding.ActivityMainBinding;
import ru.myitschool.lab23.model.Money;
import ru.myitschool.lab23.model.Operation;
import ru.myitschool.lab23.viewModel.MainActivityViewModel;

public class MainActivity extends AppCompatActivity implements MoneyOperation{
    private final static String TAG="MoneyDialog";
    private ActivityMainBinding binding;
    private RecyclerView expenses_rv;
    private TextView current_balance;
    private MainActivityViewModel viewModel;
    private List<Money> moneyList;
    private MoneyAdapter moneyAdapter;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle(R.string.app_name);
        binding=ActivityMainBinding.inflate(getLayoutInflater());
        viewModel= new ViewModelProvider(this).get(MainActivityViewModel.class);
        expenses_rv=binding.content.efExpensesRv;
        expenses_rv.setLayoutManager(new LinearLayoutManager(this));
        current_balance=binding.content.efCurrentBalanceText;
        final Observer<List<Money>> moneyObserver=new Observer<List<Money>>() {
            @Override
            public void onChanged(List<Money> updatedList) {
                if(moneyList==null)
                {
                    moneyList=updatedList;
                    moneyAdapter=new MoneyAdapter();
                    expenses_rv.setAdapter(moneyAdapter);
                }
                else
                {
                    DiffUtil.DiffResult result=DiffUtil.calculateDiff(new DiffUtil.Callback() {
                        @Override
                        public int getOldListSize() {
                            return moneyList.size();
                        }

                        @Override
                        public int getNewListSize() {
                            return updatedList.size();
                        }

                        @Override
                        public boolean areItemsTheSame(int oldItemPosition, int newItemPosition) {
                            return moneyList.get(oldItemPosition)==
                                    updatedList.get(newItemPosition);
                        }

                        @Override
                        public boolean areContentsTheSame(int oldItemPosition, int newItemPosition) {
                            Money oldMoney = moneyList.get(oldItemPosition);
                            Money newMoney = updatedList.get(newItemPosition);
                            return oldMoney.equals(newMoney);
                        }
                    });
                    result.dispatchUpdatesTo(moneyAdapter);
                    moneyList = updatedList;
                }
            }
        };
        binding.addFab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MoneyDialogFragment dialog=new MoneyDialogFragment();
                dialog.show(getSupportFragmentManager(),TAG);
            }
        });
        viewModel.getMoneyList().observe(this,moneyObserver);
        current_balance.setText(Double.toString(viewModel.ammount));
        View view=binding.getRoot();
        setContentView(view);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void add(Money money) {
        viewModel.addMoney(money);
        if(money.getOperation()==Operation.Income)
            viewModel.addAmmount(money.getSumma());
        else
            viewModel.subAmmount(money.getSumma());
        current_balance.setText(Double.toString(viewModel.ammount));
    }

    @Override
    public void delete(int id) {
        if(viewModel.getMoneyList().getValue().get(id).getOperation()==Operation.Income)
        {
            viewModel.subAmmount(viewModel.getMoneyList().getValue().get(id).getSumma());
        }
        else
            viewModel.addAmmount(viewModel.getMoneyList().getValue().get(id).getSumma());
        viewModel.deleteMoney(id);
        current_balance.setText(Double.toString(viewModel.ammount));
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void duplicate(Money money) {
        viewModel.addMoney(money);
        if(money.getOperation()==Operation.Income)
            viewModel.addAmmount(money.getSumma());
        else
            viewModel.subAmmount(money.getSumma());
        current_balance.setText(Double.toString(viewModel.ammount));
    }

    public  class MoneyAdapter extends RecyclerView.Adapter<MoneyAdapter.MoneyViewHolder>
    {
        @NonNull
        @Override
        public MoneyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.money_item, parent, false);
            return new MoneyViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(@NonNull MoneyViewHolder holder, @SuppressLint("RecyclerView") int position) {
            Money favourites = moneyList.get(position);
            holder.txtType.setText(favourites.getOperation().toString());
            SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy");
            holder.txtDate.setText(formatter.format(favourites.getDate()));
            holder.txtAmount.setText(Double.toString(favourites.getSumma()));

            View.OnLongClickListener clickListener=new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    PopupMenu popupMenu = new PopupMenu(getApplicationContext(), v);
                    popupMenu.inflate(R.menu.popup_menu);
                    popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                        @Override
                        public boolean onMenuItemClick(MenuItem item) {
                            switch (item.getItemId()) {
                                case R.id.menu1:
                                    delete(position);
                                    return true;
                                case R.id.menu2:
                                    duplicate(favourites);
                                    return true;
                                default:
                                    return false;
                            }
                        }
                    });
                    popupMenu.show();
                    return false;
                }
            };
            holder.cardView.setOnLongClickListener(clickListener);
            holder.txtDate.setOnLongClickListener(clickListener);
            holder.txtType.setOnLongClickListener(clickListener);
            holder.txtAmount.setOnLongClickListener(clickListener);
        }

        @Override
        public int getItemCount() {
            return moneyList.size();
        }


        class MoneyViewHolder extends RecyclerView.ViewHolder {
            CardView cardView;
            TextView txtType;
            TextView txtDate;
            TextView txtAmount;
            public MoneyViewHolder(@NonNull View itemView) {
                super(itemView);
                cardView=itemView.findViewById(R.id.card);
                txtType=itemView.findViewById(R.id.expense_type_text);
                txtDate=itemView.findViewById(R.id.expense_date_text);
                txtAmount=itemView.findViewById(R.id.expense_amount_text);
            }
        }
    }
}
