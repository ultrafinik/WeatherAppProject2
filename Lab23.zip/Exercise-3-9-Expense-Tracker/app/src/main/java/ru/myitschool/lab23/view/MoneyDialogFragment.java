package ru.myitschool.lab23.view;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;

import ru.myitschool.lab23.R;
import ru.myitschool.lab23.model.Money;
import ru.myitschool.lab23.model.Operation;


public class MoneyDialogFragment extends DialogFragment {
    private MoneyOperation moneyOperation;
    private String operation;
    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
            View view = inflater.inflate(R.layout.fragment_money, null);
            builder.setView(view);
            final Spinner spinner=view.findViewById(R.id.type_spinner);
            String[] typeOperation = {"Income","Expenses"};
            ArrayAdapter<String> adapter=new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item,typeOperation);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);
            AdapterView.OnItemSelectedListener itemSelectedListener=new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    operation=(String) parent.getItemAtPosition(position);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            };
            spinner.setOnItemSelectedListener(itemSelectedListener);
            final EditText edit_money=view.findViewById(R.id.expense_amount_edit_text);
            final Button button=view.findViewById(R.id.add_button);
            operation="Income";
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Operation op;
                    if(operation.equals("Income")) op=Operation.Income;
                    else op=Operation.Expenses;
                    Calendar calendar = Calendar.getInstance();
                    moneyOperation.add(new Money(op,calendar.getTime() ,Double.parseDouble(edit_money.getText().toString())));
                    dismiss();
                }
            });
        return builder.create();
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        moneyOperation=(MoneyOperation) context;
    }
}