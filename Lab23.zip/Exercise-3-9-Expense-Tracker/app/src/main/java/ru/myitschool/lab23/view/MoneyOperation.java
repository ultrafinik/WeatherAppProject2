package ru.myitschool.lab23.view;

import ru.myitschool.lab23.model.Money;

public interface MoneyOperation {
    void add(Money money);
    void delete(int id);
    void duplicate(Money money);
}
