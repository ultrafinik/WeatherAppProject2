package ru.myitschool.lab23.viewModel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.ArrayList;
import java.util.List;

import ru.myitschool.lab23.model.Money;
import ru.myitschool.lab23.model.Operation;

public class MainActivityViewModel extends ViewModel {
        private MutableLiveData<List<Money>> moneyList;
        public MutableLiveData<List<Money>> getMoneyList()
        {
                return moneyList;
        }
        public double ammount;

        public MainActivityViewModel() {
                this.moneyList = new MutableLiveData<>();
        }
        public void addMoney(Money money)
        {
                List<Money> favourites = moneyList.getValue();
                ArrayList<Money> clonedMoney;
                if (favourites == null) {
                        clonedMoney = new ArrayList<>();
                } else {
                        clonedMoney = new ArrayList<>(favourites.size());
                        for (int i = 0; i < favourites.size(); i++) {
                                clonedMoney.add(favourites.get(i));
                        }
                }
                clonedMoney.add(money);
                moneyList.setValue(clonedMoney);
        }
        public void deleteMoney(int id)
        {
                List<Money> favs = moneyList.getValue();
                ArrayList<Money> clonedFavs = new ArrayList<>(favs.size());
                for (int i = 0; i < favs.size(); i++) {
                        clonedFavs.add(favs.get(i));
                }
                clonedFavs.remove(id);
                moneyList.setValue(clonedFavs);
        }
        public void addAmmount(double sum)
        {
                ammount+=sum;
        }
        public void subAmmount(double sum)
        {
                ammount-=sum;
        }
}
